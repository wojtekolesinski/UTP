/**
 *
 *  @author Olesiński Wojciech S22368
 *
 */

package zad11;


public interface Selector <T> { // Uwaga: interfejs musi być sparametrtyzowany
	
	boolean select(T value);
}  
