/**
 *
 *  @author Olesiński Wojciech S22368
 *
 */

package zad11;


public interface Mapper <T, U>{ // Uwaga: interfejs musi być sparametrtyzowany
	
	U map(T value);
}  
