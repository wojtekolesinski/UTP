/**
 *
 *  @author Olesiński Wojciech S22368
 *
 */

package zad11;



import java.util.*;

public class ListCreator <T> { // Uwaga: klasa musi być sparametrtyzowana

	private List<T> list;

	private ListCreator(List<T> list) {
		this.list = list;
	}

	public static <T> ListCreator<T> collectFrom(List<T> list) {
		return new ListCreator<T>(list);
	}
	
	public ListCreator<T> when(Selector<T> selector) {
		List<T> temp = new ArrayList<T>();
		for (T element : list) {
			if (selector.select(element)) temp.add(element);
		}
		return new ListCreator<T>(temp);
	}
	
	public <U> List<U> mapEvery(Mapper<T, U> mapper) {
		List<U> temp = new ArrayList<U>();
		
		for (T element : list) {
			temp.add(mapper.map(element));
		}
		return temp;
	}		
}  
